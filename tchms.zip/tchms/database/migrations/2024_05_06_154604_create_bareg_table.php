<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
       Schema::create('bareg', function (Blueprint $table) {
    $table->id();
    $table->string('fname'); // First name
    $table->string('mname')->nullable(); // Middle name
    $table->string('lname'); // Last name
    $table->date('DOB'); // Date of birth
    $table->string('Prof_pic')->nullable(); // Profile picture
    $table->string('Indegency_pic')->nullable(); // Indecency picture (if needed)
    $table->string('Gender'); // Gender
    $table->string('Civil_Status'); // Civil status
    $table->string('Address'); // Address
    $table->string('Phone_number'); // Phone number
    $table->timestamps(); // Date created and updated
});

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('bareg');
    }
};
